/**
 * Default stickers and emojis presets
 */

// 聊天模块表情包与 Emoji：清空预设
export const DEFAULT_STICKERS: string[] = [];
export const DEFAULT_EMOJIS: string[] = [];

